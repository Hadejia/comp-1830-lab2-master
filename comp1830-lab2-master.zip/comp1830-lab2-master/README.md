## Lab Exercise 2 for COMP 1380

Please go to moodle to download the corresponding lab sheet.

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/apogiatzis/comp1830-lab2)